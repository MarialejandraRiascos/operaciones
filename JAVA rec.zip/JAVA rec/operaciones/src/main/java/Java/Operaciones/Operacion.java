package Java.Operaciones;

public abstract class Operacion 
{
    public abstract int operacion();
}

package Java.Operaciones;
import java.util.Scanner;
public class Ejecucion 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);

        int eleccion;

        Suma suma = new Suma();
        Resta resta = new Resta();
        Multiplicacion multiplicacion = new Multiplicacion();
        Division division = new Division();

        System.out.println("MENÚ");
        System.out.println("Seleccione la operación a realizar: \n1.Suma\n2.Resta\n3.Multiplicación\n4.División");
        eleccion = scanner.nextInt();

        switch(eleccion)
        {
            case 1: 
            System.out.println("Ingrese el primer sumando:");
            suma.setNum1(scanner.nextInt());

            System.out.println("Ingrese el segundo sumando:");
            suma.setNum2(scanner.nextInt());
            suma.operacion();
            break;

            case 2:
            System.out.println("Ingrese el minuendo: ");
            resta.setNum1(scanner.nextInt());

            System.out.println("Ingrese el sustraendo: ");
            resta.setNum2(scanner.nextInt());
            resta.operacion();
            break;

            case 3:
            System.out.println("Ingrese el multiplicando: ");
            multiplicacion.setNum1(scanner.nextInt());

            System.out.println("Ingrese el multiplicador: ");
            multiplicacion.setNum2(scanner.nextInt());
            multiplicacion.operacion();
            break;

            case 4:
            System.out.println("Ingrese el dividendo: ");
            division.setNum1(scanner.nextInt());

            System.out.println("Ingrese el divisor: ");
            division.setNum2(scanner.nextInt());
            division.operacion();
            break;

            default : break;
        }
        scanner.close();
    }
}

package Java.Operaciones;
import java.util.Scanner;
public class Resta extends Operacion
{
    Scanner scanner = new Scanner(System.in);

    int num1;
    int num2;
    int resultado;

    public Resta()  
    {

    }

    public Resta(int num1,int num2,int resultado)
    {
        this.num1 = num1;
        this.num2 = num2;
        this.resultado = resultado;
    }    

    public int getNum1() {
        return num1;
    }

    public void setNum1(int num1) {
        this.num1 = num1;
    }

    public int getNum2() {
        return num2;
    }

    public void setNum2(int num2) {
        this.num2 = num2;
    }

    public int getResultado() {
        return resultado;
    }

    public void setResultado(int resultado) {
        this.resultado = resultado;
    }

    public int operacion()
    {
        resultado = num1-num2;

        System.out.println("La diferencia de la resta es: " + resultado);
        return resultado;
    }
}
